const $ = (id) => document.getElementById(id);
const map = L.map('map', { zoomControl: false }).setView([39.0, 35.0], 6);
L.control.zoom({ position: 'bottomright' }).addTo(map);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

let routeLayers = [], markers = [], currentRoutes = [], selectedRoute = 0, lastDestination = null;
const routeColors = ['#5aa7ff', '#53d6a2', '#ffbd69'];
const fmtDuration = seconds => {
  const mins = Math.round(seconds / 60), h = Math.floor(mins / 60), m = mins % 60;
  return h ? `${h} sa ${m} dk` : `${m} dk`;
};
const fmtDistance = meters => meters >= 1000 ? `${(meters / 1000).toFixed(1).replace('.', ',')} km` : `${Math.round(meters)} m`;
function setStatus(message, error=false) { $('status').textContent = message; $('status').classList.toggle('error', error); }
function clearMap() { routeLayers.forEach(l => map.removeLayer(l)); markers.forEach(m => map.removeLayer(m)); routeLayers=[]; markers=[]; }
async function geocode(query) {
  const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=tr&q=${encodeURIComponent(query)}`;
  const response = await fetch(url, { headers: { 'Accept-Language': 'tr' } });
  if (!response.ok) throw new Error('Konum araması şu anda yanıt vermiyor.');
  const data = await response.json();
  if (!data.length) throw new Error(`Konum bulunamadı: ${query}. İl, ilçe veya açık adres yazmayı dene.`);
  return { lat: Number(data[0].lat), lon: Number(data[0].lon), name: data[0].display_name };
}
async function fetchRoutes(from, to) {
  const coords = `${from.lon},${from.lat};${to.lon},${to.lat}`;
  const url = `https://router.project-osrm.org/route/v1/driving/${coords}?overview=full&geometries=geojson&alternatives=true&steps=false`;
  const response = await fetch(url);
  if (!response.ok) throw new Error('Rota servisine ulaşılamadı. Biraz sonra tekrar dene.');
  const data = await response.json();
  if (data.code !== 'Ok' || !data.routes?.length) throw new Error('Bu iki konum arasında rota bulunamadı.');
  return data.routes.slice(0, 3);
}
function drawRoutes(routes, from, to) {
  clearMap(); currentRoutes = routes; selectedRoute = 0;
  routes.forEach((route, i) => {
    const latlngs = route.geometry.coordinates.map(([lon, lat]) => [lat, lon]);
    const layer = L.polyline(latlngs, { color: routeColors[i], weight: i===0?6:4, opacity: i===0?.95:.68, lineCap:'round' }).addTo(map);
    layer.on('click', () => selectRoute(i));
    routeLayers.push(layer);
  });
  markers.push(L.marker([from.lat,from.lon]).addTo(map).bindPopup(`<b>Başlangıç</b><br>${escapeHtml(from.name.split(',').slice(0,2).join(','))}`));
  markers.push(L.marker([to.lat,to.lon]).addTo(map).bindPopup(`<b>Varış</b><br>${escapeHtml(to.name.split(',').slice(0,2).join(','))}`));
  map.fitBounds(L.featureGroup([...routeLayers,...markers]).getBounds().pad(.12));
  $('mapHint').textContent = `${routes.length} rota bulundu`;
  renderRoutes(); selectRoute(0); lastDestination = to;
}
function renderRoutes() {
  const holder = $('routeResults'); holder.innerHTML = '';
  currentRoutes.forEach((route, i) => {
    const card = document.createElement('button'); card.type='button';
    card.className = 'route-card' + (i===selectedRoute?' selected':'');
    const name = i===0?'Önerilen rota':`Alternatif ${i}`;
    card.innerHTML = `<div class="route-top"><span class="route-name">${name}</span><span class="route-time">${fmtDuration(route.duration)}</span></div><div class="route-meta"><span>↔ ${fmtDistance(route.distance)}</span><span>◷ Tahmini sürüş süresi</span><span class="route-tag">${i===0?'Rota 1':`Rota ${i+1}`}</span></div>`;
    card.addEventListener('click',()=>selectRoute(i)); holder.appendChild(card);
  });
}
function selectRoute(index) {
  selectedRoute=index;
  routeLayers.forEach((layer,i)=>layer.setStyle({weight:i===index?7:4,opacity:i===index?1:.55}));
  [...$('routeResults').children].forEach((el,i)=>el.classList.toggle('selected',i===index));
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
async function loadWeather(place) {
  const el=$('weatherContent'); el.innerHTML='<span class="muted">Hava durumu yükleniyor…</span>';
  try {
    const url=`https://api.open-meteo.com/v1/forecast?latitude=${place.lat}&longitude=${place.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&hourly=precipitation_probability&forecast_days=1&timezone=auto`;
    const res=await fetch(url); if(!res.ok) throw new Error('Hava durumu alınamadı'); const data=await res.json();
    const c=data.current; const descriptions={0:'Açık',1:'Çoğunlukla açık',2:'Parçalı bulutlu',3:'Kapalı',45:'Sisli',48:'Kırağılı sis',51:'Hafif çisenti',53:'Çisenti',55:'Yoğun çisenti',61:'Hafif yağmur',63:'Yağmurlu',65:'Kuvvetli yağmur',71:'Hafif kar',73:'Kar yağışlı',75:'Yoğun kar',80:'Sağanak',81:'Sağanak yağmur',82:'Kuvvetli sağanak',95:'Gök gürültülü fırtına',96:'Dolu ihtimali',99:'Kuvvetli fırtına'};
    const icons={0:'☀️',1:'🌤️',2:'⛅',3:'☁️',45:'🌫️',48:'🌫️',51:'🌦️',53:'🌦️',55:'🌧️',61:'🌦️',63:'🌧️',65:'🌧️',71:'🌨️',73:'❄️',75:'❄️',80:'🌦️',81:'🌧️',82:'🌧️',95:'⛈️',96:'⛈️',99:'⛈️'};
    const times=data.hourly?.time||[], probs=data.hourly?.precipitation_probability||[];
    const hourIndex=times.findIndex(t=>t.slice(0,13)===c.time.slice(0,13)); const rain=hourIndex>=0?probs[hourIndex]:null;
    el.innerHTML=`<div class="weather-temp">${Math.round(c.temperature_2m)}°</div><div class="weather-desc"><div style="font-size:20px;margin-bottom:5px">${icons[c.weather_code]||'🌡️'}</div>${descriptions[c.weather_code]||'Hava durumu'}<br>Hissedilen ${Math.round(c.apparent_temperature)}°</div><div class="weather-stats"><span>💨 <b>${Math.round(c.wind_speed_10m)} km/sa</b> rüzgâr</span><span>💧 <b>${c.relative_humidity_2m}%</b> nem</span><span>🌧 <b>${rain===null?'—':rain+'%'}</b> yağış ihtimali</span></div>`;
  } catch(e) { el.innerHTML='<span class="muted">Hava durumu şu anda yüklenemedi. İnternet bağlantını kontrol et.</span>'; }
}
$('routeForm').addEventListener('submit',async e=>{
  e.preventDefault(); const fromText=$('fromInput').value.trim(), toText=$('toInput').value.trim(); if(!fromText||!toText)return;
  const btn=e.submitter; btn.disabled=true; btn.textContent='Rotalar aranıyor…'; $('routeResults').innerHTML=''; setStatus('Konumlar aranıyor, lütfen bekle…');
  try {
    const [from,to]=await Promise.all([geocode(fromText),geocode(toText)]);
    setStatus('Alternatif güzergâhlar hesaplanıyor…');
    const routes=await fetchRoutes(from,to); drawRoutes(routes,from,to); await loadWeather(to);
    setStatus(`${routes.length} güzergâh bulundu. İstediğin rotayı seçebilirsin.`);
  } catch(err) { setStatus(err.message||'Bir hata oluştu.',true); }
  finally { btn.disabled=false; btn.innerHTML='<span>⌁</span> Rotaları göster'; }
});
async function useCurrentLocation() {
  if(!navigator.geolocation){setStatus('Bu cihaz konum özelliğini desteklemiyor.',true);return;}
  setStatus('Konumun alınıyor…');
  navigator.geolocation.getCurrentPosition(async pos=>{
    const p=pos.coords; $('fromInput').value=`${p.latitude}, ${p.longitude}`;
    // Coordinate queries are supported by Nominatim; user may replace this with an address.
    setStatus('Konum alındı. Varış noktasını girip rota ara.');
    try { const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${p.latitude}&lon=${p.longitude}`,{headers:{'Accept-Language':'tr'}}); const d=await r.json(); if(d.display_name)$('fromInput').value=d.display_name; } catch(_){}
    map.setView([p.latitude,p.longitude],13);
  },()=>setStatus('Konum izni alınamadı. Tarayıcı/uygulama ayarlarından konum izni ver.',true),{enableHighAccuracy:true,timeout:10000});
}
$('useCurrentBtn').addEventListener('click',useCurrentLocation); $('locateBtn').addEventListener('click',useCurrentLocation);
$('fitBtn').addEventListener('click',()=>{if(routeLayers.length)map.fitBounds(L.featureGroup(routeLayers).getBounds().pad(.12));else map.setView([39,35],6);});
if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
