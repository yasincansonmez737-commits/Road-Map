# YolPusula — Akıllı Yol Asistanı

Mobil öncelikli, HTML/CSS/JavaScript tabanlı alternatif rota ve hava durumu uygulaması. Vite ile web olarak çalışır; Capacitor ile Android projesine dönüştürülebilir.

## Özellikler
- Nereden / nereye konum arama (Türkiye odaklı)
- OSRM üzerinden sürüş rotası ve varsa alternatif rotalar
- Haritada rotaları karşılaştırma ve seçme
- Open-Meteo üzerinden varış noktasının güncel hava durumu, sıcaklık, rüzgâr, nem ve saatlik yağış olasılığı
- Mevcut konumu kullanma (izin verilirse)
- Mobil uyumlu arayüz ve temel PWA önbelleği

## Veri sağlayıcıları ve önemli sınırlar
- Harita: OpenStreetMap
- Adres arama: Nominatim
- Rota: OSRM demo servisi
- Hava durumu: Open-Meteo
- **Bu başlangıç sürümünde canlı trafik yoğunluğu verisi yoktur.** OSRM rota süreleri canlı trafik gecikmesini göstermez. Kırmızı/yeşil trafik katmanı veya gerçek trafikle yeniden hesaplama bu kodda varmış gibi sunulmaz. Canlı trafik için uygun bir sağlayıcı (ör. TomTom Routing/Traffic veya Google Routes) ve API anahtarıyla ayrı entegrasyon gerekir.
- Ücretsiz demo servisleri kota, hız sınırlaması ve kullanım politikası uygulayabilir. Üretim kullanımı için servis şartlarını inceleyin; Nominatim'i otomatik ve yoğun sorgularla kullanmayın.
- Harita kutucukları ve API'ler için internet gerekir. Çevrimdışı modda rota/hava durumu çalışmaz.
- Konum özelliği HTTPS veya localhost gerektirir. Android paketinde Capacitor'ın konum izinlerini ayrıca yapılandırın.

## Bilgisayarda çalıştırma
Node.js LTS kurulu olmalı. Proje klasöründe terminal açın:

```bash
npm install
npm run start
```

Vite'ın gösterdiği yerel adresi tarayıcıda açın.

Üretim web derlemesi:

```bash
npm run build
npm run preview
```

## GitHub'a yükleme
1. GitHub'da yeni bir repository oluşturun: `yolpusula`.
2. Bu klasörde terminal açın:

```bash
git init
git add .
git commit -m "YolPusula ilk sürüm"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/yolpusula.git
git push -u origin main
```

`KULLANICI_ADIN` yerine kendi GitHub kullanıcı adınızı yazın.

## Android APK oluşturma
Gerekli araçlar: Node.js LTS, Android Studio ve Android SDK.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio açıldığında Gradle senkronizasyonunu bekleyin. Test için Run düğmesini kullanın. APK üretmek için **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin. Android Studio oluşturulan APK dosyasının konumunu gösterir.

> `android/` klasörü `.gitignore` içinde olduğu için otomatik olarak GitHub'a yüklenmez. Android Studio/Capacitor gerektiğinde yeniden oluşturabilir. Android klasörünü repoda tutmak isterseniz `.gitignore` içindeki `android/` satırını kaldırın.

## Sonraki üretim adımları
- Canlı trafik API'si ve trafik bazlı alternatif rota hesaplama
- Android konum izinlerinin ve geri tuşunun düzenlenmesi
- Hata/limit durumları, servis sağlayıcı koşulları ve gizlilik metni
- Uygulama simgesi, açılış ekranı ve gerçek cihaz testleri
